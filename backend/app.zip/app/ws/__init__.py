"""WebSocket package."""
