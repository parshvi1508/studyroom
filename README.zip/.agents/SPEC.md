# StudyRoom - Product Specification

## What This Is

A web-based collaborative study room platform where users create virtual study rooms,
join via room codes, track study sessions with a server-authoritative timer, and
communicate via realtime chat.

Built as a technical assessment for Jaypee Brothers Medical Publishers.

## What This Is NOT

- A video/audio calling platform
- A content management system
- A social network
- A file sharing platform

## Frozen Scope (V1)

### In Scope

- User registration and login (JWT-based)
- Create a study room (returns a unique 6-character room code)
- Join a room using a room code
- Realtime presence: see who is currently in the room
- Realtime chat within a room (messages persisted to DB)
- Server-authoritative session timer (start, pause, end)
- Session activity log per room (who joined, session started/ended, duration)
- Basic activity dashboard per user (their session history, total study time)

### Out of Scope for V1

- Email invitations (room code is the invite mechanism)
- Video or audio
- File or resource sharing
- Rich text in chat
- Push notifications
- Mobile app
- Multiple concurrent sessions per room
- Role changes after room creation

## Non-Functional Requirements

| Requirement | Target | Notes |
|---|---|---|
| API response time (non-WS) | < 200ms p95 | Supabase in same region |
| WebSocket message latency | < 100ms | Single-region deployment |
| Concurrent WebSocket connections | 100 per instance (V1) | Architecture must allow Redis upgrade path |
| Auth token expiry | 60 minutes access token | No refresh token in V1 |
| Room code collision probability | < 0.1% at 10,000 rooms | 6-char alphanumeric = 2.1B combos |

## Upgrade Path (documented, not built in V1)

The `ConnectionManager` class uses an in-memory store in V1.
Replacing it with a Redis-backed pub/sub implementation must require
changes only inside `ConnectionManager`, with no changes to route handlers or
WebSocket endpoint logic. This is enforced by the interface design.
