# WebSocket Message Protocol
# Every message sent over a WebSocket connection is typed here.
# No raw dicts anywhere in the codebase.

## Client to Server Messages

### join_room
Sent automatically on WebSocket connection open. No body needed.
Auth is via JWT query parameter on the WS URL.

### chat_message
{
  "type": "chat_message",
  "content": "string, max 1000 chars"
}

### start_session
{
  "type": "start_session"
}
Only accepted from the room creator. Rejected with error event otherwise.

### end_session
{
  "type": "end_session"
}
Only accepted from the room creator. Rejected with error event otherwise.

## Server to Client Events

### user_joined
{
  "type": "user_joined",
  "user_id": "uuid",
  "display_name": "string",
  "participants": ["list of current participants with id and display_name"]
}

### user_left
{
  "type": "user_left",
  "user_id": "uuid",
  "display_name": "string",
  "participants": ["updated participant list"]
}

### chat_message
{
  "type": "chat_message",
  "message_id": "uuid",
  "user_id": "uuid",
  "display_name": "string",
  "content": "string",
  "sent_at": "ISO 8601 UTC timestamp"
}

### session_started
{
  "type": "session_started",
  "session_id": "uuid",
  "started_by": "uuid",
  "start_time": "ISO 8601 UTC timestamp"
}
Clients compute elapsed time from start_time. No server-push ticking.

### session_ended
{
  "type": "session_ended",
  "session_id": "uuid",
  "end_time": "ISO 8601 UTC timestamp",
  "duration_seconds": "integer"
}

### error
{
  "type": "error",
  "code": "string (e.g. UNAUTHORIZED, SESSION_ALREADY_ACTIVE, NOT_ROOM_CREATOR)",
  "message": "human-readable string"
}

### ping (server to client, every 30 seconds)
{
  "type": "ping"
}
Client responds with pong. Keeps Azure/proxy connections alive.

### pong (client to server)
{
  "type": "pong"
}
