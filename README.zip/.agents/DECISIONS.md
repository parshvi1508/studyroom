# Architectural Decision Record

Every significant technical decision is recorded here with rationale.
Once a decision is marked FROZEN, it is not changed without updating this file first.

---

## ADR-001: Async FastAPI for all backend routes

**Status:** FROZEN
**Decision:** All backend code uses async/await throughout. No synchronous database calls.
**Rationale:** WebSocket connections are inherently concurrent. Mixing sync DB calls with
async WebSocket handlers causes thread starvation in a single-process deployment.
Async SQLAlchemy with asyncpg driver eliminates this class of problem.
**Consequence:** All developers must understand async Python. No `requests` library.
Use `httpx` for any outbound HTTP.

---

## ADR-002: Supabase PostgreSQL from day one

**Status:** FROZEN
**Decision:** No SQLite at any stage. Supabase PostgreSQL is the only database.
**Rationale:** SQLite's async driver (aiosqlite) has known edge cases with concurrent
WebSocket writes to the same table. Supabase provides a hosted PostgreSQL instance
with connection pooling via PgBouncer. Eliminates a category of bugs before they appear.
**Consequence:** Requires a Supabase project and connection string before first run.
Documented in README.

---

## ADR-003: In-memory ConnectionManager with Redis upgrade path

**Status:** FROZEN
**Decision:** V1 uses an in-memory dict inside `ConnectionManager` to track active
WebSocket connections per room. The class interface is designed so that swapping
the storage backend to Redis requires no changes outside the class.
**Rationale:** Redis adds operational complexity that is not justified at demo scale.
The class boundary enforces separation of concerns and makes the upgrade path clear
to any reviewer reading the code.
**Scaling trigger:** Add Redis pub/sub when deploying more than one backend instance.

---

## ADR-004: Server-authoritative session timer

**Status:** FROZEN
**Decision:** The server stores `session_start_time` as a UTC timestamp in the database.
Clients compute elapsed time by subtracting `session_start_time` from the current UTC time.
The server broadcasts a `SESSION_STARTED` event with the timestamp, not a countdown.
**Rationale:** Client-side timers drift on tab switch, sleep, or reconnect. A reconnecting
client can always compute the correct elapsed time from the server timestamp without
requiring a dedicated sync message.
**Consequence:** All clients must handle UTC timestamps correctly. Frontend uses
`Date.now()` against the server-provided UTC start timestamp.

---

## ADR-005: WebSocket token via query parameter

**Status:** FROZEN
**Decision:** JWT is passed as `?token=<jwt>` on the WebSocket upgrade URL.
**Rationale:** Browser WebSocket API does not support custom headers on the initial
handshake. Query parameter is the standard workaround.
**Security note:** The token is visible in server access logs. Acceptable for V1.
Mitigation for V2: short-lived single-use WebSocket ticket exchanged via REST before
the WebSocket handshake.

---

## ADR-006: OOP for service and manager layers

**Status:** FROZEN
**Decision:** Business logic lives in service classes, not in route handlers.
Route handlers call service methods. Service classes own DB interactions.
`ConnectionManager` is a standalone class owning all WebSocket state.
**Rationale:** Single Responsibility Principle. Route handlers handle HTTP concerns.
Service classes handle business logic. `ConnectionManager` handles connection state.
Each is independently testable.
**Pattern enforced:**
- `routes/` contains only FastAPI route definitions and dependency injection
- `services/` contains classes with business logic
- `ws/` contains `ConnectionManager` and WebSocket endpoint handlers

---

## ADR-007: Pydantic models for all WebSocket messages

**Status:** FROZEN
**Decision:** Every WebSocket message sent or received is validated against a Pydantic model.
No raw dicts are broadcast or parsed.
**Rationale:** Type safety, automatic validation, and self-documenting message contracts.
A reviewer reading the code understands the message protocol from the schema file alone.

---

## ADR-008: Deployment target

**Status:** FROZEN
**Decision:** Backend on Azure App Service B1. Frontend on Vercel.
**Rationale:** Azure App Service supports persistent WebSocket connections.
HuggingFace Spaces drops WebSocket connections after ~55 seconds of inactivity.
Render is the fallback if Azure credits are exhausted.
**Database:** Supabase (no change regardless of backend deployment target).

---

## ADR-009: Room code generation

**Status:** FROZEN
**Decision:** 6-character alphanumeric (uppercase letters + digits, excluding 0/O/I/1
for readability). Generated server-side using `secrets.choice`. Unique constraint
enforced at database level. Retry up to 5 times on collision before raising a 503.
**Rationale:** 32^6 = 1,073,741,824 possible codes. Collision probability is negligible
at demo scale. The retry loop with a hard limit prevents an infinite loop in the
pathological case.
