# RULES.md - Coding Standards and Agent Behavior

These rules apply to every file in this repository.
Any AI agent or human contributor must follow them without exception.

---

## Agent Behavior Rules

1. Before touching any file, state the exact file path and what change you intend to make.
   Wait for explicit approval. "ok" or "yes" counts. Silence does not.

2. Before writing any new file, check if a related file already exists that should be
   modified instead. Do not create duplicate files.

3. Read SPEC.md and DECISIONS.md before writing or editing any file.

4. If a task requires a decision not covered in DECISIONS.md, raise it explicitly.
   Do not silently make architectural choices.

5. Do not refactor code that is not directly related to the current task.

---

## Code Style Rules

### Forbidden in all files

- Em dashes (--) anywhere in code, comments, or docstrings
- Emojis in any file including markdown
- Comments that restate what the code does (`# increment counter` above `counter += 1`)
- `print()` statements in any backend file. Use `logging`.
- Hardcoded secrets, API keys, or connection strings
- Unused imports
- Raw dict payloads in WebSocket send/receive. Use Pydantic models.
- `SELECT *` in any raw SQL query
- Synchronous database calls inside async functions

### Required in all Python files

- Every class has a docstring explaining its responsibility, not its implementation
- Every public method has a docstring explaining what it does and what it returns
- All route handlers have a `response_model` defined
- All secrets loaded via `pydantic-settings` from environment variables
- Type hints on all function signatures
- `logging.getLogger(__name__)` at the top of every module that logs

### Naming conventions

- Files: `snake_case.py`
- Classes: `PascalCase`
- Functions and variables: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Pydantic models for requests: suffix `Request` (e.g., `CreateRoomRequest`)
- Pydantic models for responses: suffix `Response` (e.g., `RoomResponse`)
- Pydantic models for WebSocket messages: suffix `Event` (e.g., `ChatMessageEvent`)

### Python-specific

- Use `async def` for all database operations and WebSocket handlers
- Use `asyncpg` as the PostgreSQL driver (via SQLAlchemy async)
- Use `python-jose` for JWT encoding/decoding
- Use `passlib[bcrypt]` for password hashing
- No mutable default arguments
- No bare `except:` clauses. Catch specific exceptions.

---

## Git Rules

- Commit messages: `type: short description` (e.g., `feat: add room creation endpoint`)
- Types: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`
- No commented-out code committed. Delete it or keep it.
- No `.env` files committed. `.env.example` with placeholder values is required.

---

## Security Rules

- All endpoints except `/auth/register` and `/auth/login` require a valid JWT
- WebSocket endpoint validates JWT from query parameter before accepting the connection
- Passwords stored as bcrypt hashes only, never plaintext
- Room codes are not sequential and not guessable (use `secrets` module)
- CORS origins must be explicitly configured, never `*` in production
- All user input validated via Pydantic before any database operation

---

## What "Done" Means for Any Task

A task is done when:
1. The feature works as specified in SPEC.md
2. No existing tests are broken
3. The code follows all rules in this file
4. The relevant decision is recorded in DECISIONS.md if a new architectural choice was made
